#!/bin/bash

export PS1="\u@\h>\d\t "
